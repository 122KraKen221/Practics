﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppPrac.Classes;
using WpfAppPrac.Pages;

namespace WpfAppPrac
{
    /// <summary>
    /// Логика взаимодействия для WindowRegistration.xaml
    /// </summary>
    public partial class WindowRegistration : Window
    {
        private Users User = new Users();
        public WindowRegistration(Users selectedUser, string text)
        {
            InitializeComponent();
            Refresh();

            string userlev = text;
            if (selectedUser != null)
                User = selectedUser;
            DataContext = User;
            if (userlev != "adm")
            {

                cmbPlace.Visibility = Visibility.Hidden;
                textLevel.Visibility = Visibility.Hidden;

            }

        }
        private void Refresh()
        {
            try
            {

                cmbPlace.ItemsSource = PracWorksEntities.GetContext().Users.Select(x => x.Level_Access).Distinct().ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnMin_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnMax_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                WindowState = WindowState.Normal;
            }
        }

        private void StackPanel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            this.DragMove();
        }

        private void btnAdd_Edit_Click(object sender, RoutedEventArgs e)
        {
            String Login = txbLogin.Text;
            String Password = txbPassword.Text;
            bool isUserExists = PracWorksEntities.GetContext().Users.Any(x => x.Login == Login);
            try
            {

                if (User.ID == 0)
                {
                    if (Login != "" && Password != "")
                    {
                        if (isUserExists == false)
                        {
                            PracWorksEntities.GetContext().Users.Add(User);
                            PracWorksEntities.GetContext().SaveChanges();

                            MessageBox.Show("Изменения успешно внесены/сохранены");

                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Такой пользователь уже есть");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Поля не должны быть пустыми");
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

        }

        private void windowFrame_Loaded(object sender, RoutedEventArgs e)
        {
            if (cmbPlace.SelectedValue == null)
            {
                cmbPlace.SelectedValue = "Сотрудник";
            }
        }
    }
}
