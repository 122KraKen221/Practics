﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.CommandTrees;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppPrac.Classes;

namespace WpfAppPrac.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAutorisation.xaml
    /// </summary>
    public partial class PageAutorisation : Page
    {
        public PageAutorisation()
        {
            InitializeComponent();
        }
        private void btnLog_Click(object sender, RoutedEventArgs e)
        {
            String Login = txbox1.Text;
            String Password = Psbox.Password;

            if (Login != "" && Password != "")
            {
                var user = PracWorksEntities.GetContext().Users.FirstOrDefault(x => x.Login == txbox1.Text && x.Password == Psbox.Password);
                if (user != null)
                {
                    if (user.Level_Access == "Администратор")
                    {
                        MessageBox.Show($"Администратор авторизирован!");
                        ClassFrame.FrmObj.Navigate(new PageMenu(user));
                        txbox1.Text = null;
                        Psbox.Password=null;
                    }
                    else if (user.Level_Access == "Сотрудник")
                    {
                        MessageBox.Show($"Сотрудник авторизирован!");
                        ClassFrame.FrmObj.Navigate(new PageMenu(user));
                        txbox1.Text = null;
                        Psbox.Password = null;
                    }
                }
                else MessageBox.Show("Данный пользователь не существует");
            }
            else
            {
                MessageBox.Show("Поля не должны быть пустыми");
            }
        }

        private void txbox1_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Down)
                Psbox.Focus();
        }

        private void Psbox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Up)
                txbox1.Focus(); 
        }

        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<WindowRegistration>().Any())
            {
                System.Media.SystemSounds.Asterisk.Play();

            }
            else
            {
                string text = null;
                WindowRegistration WindowRegistration = new WindowRegistration((sender as System.Windows.Controls.Button).DataContext as Users, text);
                WindowRegistration.Show();
            }
        }
    }
}
