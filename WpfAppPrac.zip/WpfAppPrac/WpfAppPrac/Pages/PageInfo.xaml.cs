﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Data.Entity.Core.Metadata.Edm;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Activation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppPrac.Classes;

namespace WpfAppPrac.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageInfo.xaml
    /// </summary>
    public partial class PageInfo : Page
    {
        public PageInfo(Users user)
        {
            InitializeComponent();
            Refr();
            
            if (user.Level_Access == "Сотрудник")
            {
                btnEidit.Visibility = Visibility.Collapsed;
                btnAdd.Visibility = Visibility.Collapsed;
                btnDel.Visibility = Visibility.Collapsed;
            }
            var listDisc =
                PracWorksEntities.GetContext().Employees.Select(x => x.Place_Work).Distinct().ToList();
            CmbSelection.Items.Add("Все места");
            foreach (var item in listDisc)
            {
                CmbSelection.Items.Add(item);
            }
        }
        public void Refr()
        {
            //DbNumber.ItemsSource = PracWorksEntities.GetContext().Employees.ToList();
            DbNumber.ItemsSource = PracWorksEntities.GetContext().Employees.OrderBy(x => x.Number).ToList();
        }


        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ClassFrame.FrmObj.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            WindowAdd Windowadd = new WindowAdd((sender as Button).DataContext as Employees);
            Windowadd.Show();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<WindowAdd>().Any())
            {
                System.Media.SystemSounds.Asterisk.Play();

            }
            else
            {
                WindowAdd Windowadd = new WindowAdd((sender as System.Windows.Controls.Button).DataContext as Employees);
                Windowadd.Show();
            }



        }

        private void btnDel_Click(object sender, RoutedEventArgs e)
        {
            var NumberForRemoving = DbNumber.SelectedItems.Cast<Employees>().ToList();
            if (NumberForRemoving.Count() != 0)
            {
                if (MessageBox.Show($"Удалить {NumberForRemoving.Count()}" + " Номеров?",
                    "Внимение", MessageBoxButton.YesNo,
                    MessageBoxImage.Question) == MessageBoxResult.Yes)

                    try
                    {
                        PracWorksEntities.GetContext().Employees.RemoveRange(NumberForRemoving);
                        PracWorksEntities.GetContext().SaveChanges();

                        MessageBox.Show("Данные удалены");

                        Refr();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message.ToString());
                    }
            }
            else
            {
                MessageBox.Show("Вы не выбрали кого удалить");
            }

        }

        private void CmbSelection_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string PlaceWork = CmbSelection.SelectedValue.ToString();
            if (PlaceWork == "Все места")
                DbNumber.ItemsSource =
               PracWorksEntities.GetContext().Employees.ToList();
            else
                DbNumber.ItemsSource =
                    PracWorksEntities.GetContext().Employees.
                    Where(x => x.Place_Work == PlaceWork).ToList();
        }

        private void txtboxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = txtboxSearch.Text;
            DbNumber.ItemsSource =
                PracWorksEntities.GetContext().Employees.
                Where(X => X.Number.ToString().Contains(search)).ToList();
        }



        private void btnsearchNumber_Click(object sender, RoutedEventArgs e)
        {
            int i = 1;
            foreach (Employees employee in DbNumber.Items)
            {

                var cellValue = employee.Number;
                if (i == cellValue)
                {
                    i++;
                }
                else if (i != cellValue)
                {

                    MessageBox.Show($"Следующий свободный номер: {i} ");
                    break;
                }
                if (i == DbNumber.Items.Count)
                {

                    MessageBox.Show($"Следующий свободный номер: {i} ");
                    break;
                }
            }



        }

        private void btnRefr_Click(object sender, RoutedEventArgs e)
        {
            Refr();
        }
    }
    
}
        

    
