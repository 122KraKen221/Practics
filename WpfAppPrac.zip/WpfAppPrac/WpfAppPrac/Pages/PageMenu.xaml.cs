﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppPrac.Classes;

namespace WpfAppPrac.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMenu.xaml
    /// </summary>
    public partial class PageMenu : Page
    {
        private Users User = new Users();
        public PageMenu(Users user)
        {
            InitializeComponent();
            if (user != null)
                User = user;
            DataContext = User;
            
        }
        

        private void btninf_Click(object sender, RoutedEventArgs e)
        {
 
            ClassFrame.FrmObj.Navigate( new PageInfo(User));
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.FrmObj.GoBack();
        }

        private void btnUser_Click(object sender, RoutedEventArgs e)
        {

        }

        
    }
}
