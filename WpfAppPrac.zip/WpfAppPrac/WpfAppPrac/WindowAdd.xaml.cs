﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppPrac.Classes;
using WpfAppPrac.Pages;

namespace WpfAppPrac
{
    /// <summary>
    /// Логика взаимодействия для WindowAdd.xaml
    /// </summary>
    public partial class WindowAdd : Window
    {
        private Employees emoloyees = new Employees();
        public WindowAdd(Employees selectedEmployees)
        {
            InitializeComponent();
            Refresh();

            if (selectedEmployees != null)
                emoloyees = selectedEmployees;
            DataContext = emoloyees;
        }
        private void Refresh()
        {
            try
            {

                cmbPlace.ItemsSource = PracWorksEntities.GetContext().Employees.Select(x =>x.Place_Work).Distinct().ToList();
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
                this.Close();
        }

        private void btnMin_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnMax_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                WindowState = WindowState.Normal;
            }
        }

        private void StackPanel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            this.DragMove();
        }

        private void btnAdd_Edit_Click(object sender, RoutedEventArgs e)
        {
            int Number = Convert.ToInt32(txbNumber.Text);
            bool isEmployeessExists = PracWorksEntities.GetContext().Employees.Any(x => x.Number == Number);
            try
            {
                if (emoloyees.ID == 0)
                {
                    if (txbEmail.Text != "" && txbNumber.Text != "" && txbPhone.Text != "" && cmbPlace.SelectedItem != null)
                    {
                        if (isEmployeessExists == false)
                        {
                            PracWorksEntities.GetContext().Employees.Add(emoloyees);
                            PracWorksEntities.GetContext().SaveChanges();

                            MessageBox.Show("Изменения успешно внесены/сохранены");

                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Такой работник уже есть");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Поля не должны быть пустыми");
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        
        }
    }
}

