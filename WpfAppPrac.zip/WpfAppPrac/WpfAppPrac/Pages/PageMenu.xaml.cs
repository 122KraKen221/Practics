﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppPrac.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace WpfAppPrac.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMenu.xaml
    /// </summary>
    public partial class PageMenu : Page
    {
        private Users User = new Users();
        public PageMenu(Users user)
        {
            InitializeComponent();
            if (user != null)
                User = user;
            DataContext = User;
            if (User.Level_Access == "Сотрудник")
            {
                btnUser.Visibility = Visibility.Collapsed;
            }
            
        }
        

        private void btninf_Click(object sender, RoutedEventArgs e)
        {
 
            ClassFrame.FrmObj.Navigate( new PageInfo(User));
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.FrmObj.GoBack();
        }

        private void btnUser_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.FrmObj.Navigate(new PageUsers(User));
        }
        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {
            //объект Excel
            var app = new Excel.Application();

            //книга 
            Excel.Workbook wb = app.Workbooks.Add();
            //лист
            Excel.Worksheet worksheet =
                app.Worksheets.Item[1];

            int indexRows = 1;
            //ячейка
            worksheet.Cells[1][indexRows] = "ID";
            worksheet.Cells[2][indexRows] = "Номер";
            worksheet.Cells[3][indexRows] = "Почта";
            worksheet.Cells[4][indexRows] = "Телефон";
            worksheet.Cells[5] [indexRows] = "Место работы";
            worksheet.Columns[1].ColumnWidth = 5;
            worksheet.Columns[2].ColumnWidth = 10;
            worksheet.Columns[3].ColumnWidth = 25;
            worksheet.Columns[4].ColumnWidth = 15;
            worksheet.Columns[5].ColumnWidth = 10;
            var listEmployees = PracWorksEntities.
                GetContext().Employees.ToList();
            foreach (var employees in listEmployees)
            {
                indexRows++;
                worksheet.Cells[1][indexRows] = indexRows - 1;
                worksheet.Cells[2][indexRows] = employees.Number;
                worksheet.Cells[3][indexRows] = employees.Email;
                worksheet.Cells[4][indexRows] = employees.Phone;
                worksheet.Cells[5][indexRows] = employees.Place_Work;
            }
            //показать Excel
            app.Visible = true;
        }

        
    }
}
