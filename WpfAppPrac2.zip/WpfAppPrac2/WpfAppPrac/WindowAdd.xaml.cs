﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfAppPrac.Classes;
using WpfAppPrac.Pages;

namespace WpfAppPrac
{
    /// <summary>
    /// Логика взаимодействия для WindowAdd.xaml
    /// </summary>
    public partial class WindowAdd : Window
    {
        private Employees emoloyees = new Employees();
        
        public WindowAdd(Employees selectedEmployees)
        {
            InitializeComponent();
            Refresh();

            if (selectedEmployees != null)
                emoloyees = selectedEmployees;
            DataContext = emoloyees;
        }
        private void Refresh()
        {
            try
            {

                cmbPlace.ItemsSource = PracWorksEntities.GetContext().Objects.ToList();
                cmbPlace.SelectedValuePath = "Objects_Id";
                cmbPlace.DisplayMemberPath = "Name";
                cmbJob.ItemsSource= PracWorksEntities.GetContext().Jobs.ToList();
                cmbJob.SelectedValuePath = "Job_Id";
                cmbJob.DisplayMemberPath = "Description";
                cmbAccess.ItemsSource = PracWorksEntities.GetContext().Level_Access.ToList();
                cmbAccess.SelectedValuePath = "ID";
                cmbAccess.DisplayMemberPath = "Level_Access1";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
                this.Close();
        }

        private void btnMin_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btnMax_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Normal)
            {
                WindowState = WindowState.Maximized;
            }
            else
            {
                WindowState = WindowState.Normal;
            }
        }

        private void StackPanel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            this.DragMove();
        }

        private void btnAdd_Edit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var value = int.Parse(txbNumber.Text); //Преобразуем текст в int
                var result = (from t in PracWorksEntities.GetContext().Employees
                              where t.ID == value
                              select t).FirstOrDefault(); //Ищем запись с нужным id
                if (result == null)
                {  
                    if (txbEmail.Text != ""  && txbPhone.Text != "" && cmbPlace.SelectedItem != null)
                    {
                        PracWorksEntities.GetContext().Employees.Add(emoloyees);
                    }
                    else
                    {
                        MessageBox.Show("Поля не должны быть пустыми");  
                    }
         
             
                }
            
              PracWorksEntities.GetContext().SaveChanges();
              MessageBox.Show("Изменения успешно внесены/сохранены");
              this.Close(); 
                
                      
                
                 

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }

        }
    }
}

