﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppPrac.Classes;

namespace WpfAppPrac.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageUsers.xaml
    /// </summary>
    public partial class PageUsers : Page
    {

        public PageUsers(Users user)
        {
            InitializeComponent();
            DbUser.ItemsSource = PracWorksEntities.GetContext().Users.ToList();
            var listDisc =
                PracWorksEntities.GetContext().Users.Select(x => x.Level_Access).Distinct().ToList();
            CmbSelection.Items.Add("Все Уровни");
            foreach (var item in listDisc)
            {
                CmbSelection.Items.Add(item);
            }
              
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ClassFrame.FrmObj.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<WindowRegistration>().Any())
            {
                System.Media.SystemSounds.Asterisk.Play();

            }
            else
            {
                string userlev = "adm";
                WindowRegistration WindowRegistration = new WindowRegistration((sender as System.Windows.Controls.Button).DataContext as Users,userlev );
                WindowRegistration.Show();
            }
        }

        private void btnDel_Click(object sender, RoutedEventArgs e)
        {
            var UserForRemoving = DbUser.SelectedItems.Cast<Users>().ToList();

            if (MessageBox.Show($"Удалить {UserForRemoving.Count()}" + " Пользователей?",
                "Внимение", MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.Yes)

                try
                {
                    PracWorksEntities.GetContext().Users.RemoveRange(UserForRemoving);
                    PracWorksEntities.GetContext().SaveChanges();

                    MessageBox.Show("Данные удалены");

                    DbUser.ItemsSource = PracWorksEntities.GetContext().Users.ToList();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
        }

        private void CmbSelection_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string Level_Access = CmbSelection.SelectedValue.ToString();
            if (Level_Access == "Все Уровни")
                DbUser.ItemsSource =
               PracWorksEntities.GetContext().Users.ToList();
            else
                DbUser.ItemsSource =
                    PracWorksEntities.GetContext().Users.
                    Where(x => x.Level_Access == Level_Access).ToList();
        }

        private void txtboxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = txtboxSearch.Text;
            DbUser.ItemsSource =
                PracWorksEntities.GetContext().Users.
                Where(X => X.Login.ToString().Contains(search)).ToList();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e )
        {
            string userlev = "adm";
            WindowRegistration WindowRegistration = new WindowRegistration((sender as Button).DataContext as Users, userlev);
            WindowRegistration.Show();
        }
    }
}
