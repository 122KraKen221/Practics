﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfAppPrac.Classes;

namespace WpfAppPrac.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageUsers.xaml
    /// </summary>
    public partial class PageUsers : Page
    {

        public PageUsers(Employees level)
        {
            InitializeComponent();
            Refr();
            var listDisc =
                PracWorksEntities.GetContext().Level_Access.Select(x => x.Level_Access1).Distinct().ToList();
            CmbSelection.Items.Add("Все Уровни");
            foreach (var item in listDisc)
            {
                CmbSelection.Items.Add(item);
            }
              
        }
        public void Refr()
        {
            //DbNumber.ItemsSource = PracWorksEntities.GetContext().Employees.ToList();
            DbUser.ItemsSource = PracWorksEntities.GetContext().Employees.OrderBy(x => x.ID).ToList();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ClassFrame.FrmObj.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void CmbSelection_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string Level_Access = CmbSelection.SelectedValue.ToString();
            if (Level_Access == "Все Уровни")
                DbUser.ItemsSource =
               PracWorksEntities.GetContext().Employees.ToList();
            else
                DbUser.ItemsSource =
                    PracWorksEntities.GetContext().Employees.
                    Where(x => x.Level_Access.Level_Access1 == Level_Access).ToList();
        }

        private void txtboxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = txtboxSearch.Text;
            DbUser.ItemsSource =
                PracWorksEntities.GetContext().Employees.
                Where(X => X.Login.ToString().Contains(search)).ToList();
        }


        private void btnRefr_Click(object sender, RoutedEventArgs e)
        {
            Refr();
        }
    }
}
